#!/usr/bin/env python3

import requests,sys

if len(sys.argv) < 2:
    print("Usage : open-redirect-scanner.py <target_url>")
    exit()


def main():
    _,target = sys.argv
    file = "payloads.list"

    with open(file,"r") as f:
        print("Performing Open redirect scan..")

        for line in f:
                nline = line.strip()
                line2 = target + nline
                print(line2)
                response = requests.get(line2,verify=True)
                print(response)
                if response.history:
                    print("request was redirected")

                    for resp in response.history:
                        print("|")
                        print(resp.status_code,resp.url)

                    print("final destination:")

                    print("+")
                    print(resp.status_code,resp.url)


main()
